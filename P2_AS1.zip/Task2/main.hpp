/*
* Author: Võ Tiến
* Date: 26.02.2023
* FB: https://www.facebook.com/profile.php?id=100056605580171
* FB nhóm: https://www.facebook.com/groups/211867931379013
*/
#ifndef DSA232_A1_MAIN_H
#define DSA232_A1_MAIN_H

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <iomanip>
#include <string>
#include <cstring>
#include <sstream>
#include <fstream>
#include <cassert>

using namespace std;
static ofstream OUTPUT;
#define folder_input  "TestCase_Task2/input/input"
#define folder_output "TestCase_Task2/output/output"
#define folder_expect "TestCase_Task2/expect/expect"

#endif //DSA232_A1_MAIN_H